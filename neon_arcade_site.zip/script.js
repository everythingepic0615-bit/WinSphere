const games = [
 {id:'2048',name:'2048',desc:'Slide, combine, and reach the big tile.',category:'puzzle',emoji:'🔢',cover:'cover-purple',url:'https://play2048.co/'},
 {id:'snake',name:'Snake',desc:'Eat, grow, and avoid your own tail.',category:'arcade',emoji:'🐍',cover:'cover-green',url:'https://www.google.com/fbx?fbx=snake_arcade'},
 {id:'tetris',name:'Tetris',desc:'Stack the blocks and clear the lines.',category:'puzzle',emoji:'🧱',cover:'cover-blue',url:'https://tetris.com/play-tetris'},
 {id:'chess',name:'Chess',desc:'Plan ahead and outsmart your opponent.',category:'strategy',emoji:'♟️',cover:'cover-dark',url:'https://www.chess.com/play'},
 {id:'agar',name:'Agar.io',desc:'Grow bigger and climb the leaderboard.',category:'action',emoji:'🟣',cover:'cover-pink',url:'https://agar.io/'},
 {id:'slither',name:'Slither.io',desc:'Become the longest snake in the arena.',category:'arcade',emoji:'🐉',cover:'cover-cyan',url:'https://slither.io/'},
 {id:'football',name:'Football Games',desc:'Find a quick soccer challenge.',category:'sports',emoji:'⚽',cover:'cover-orange',url:'https://www.crazygames.com/t/football'},
 {id:'racing',name:'Racing Games',desc:'Pick a ride and hit the track.',category:'action',emoji:'🏎️',cover:'cover-red',url:'https://www.crazygames.com/t/racing'}
];
const grid=document.getElementById('gameGrid'), favGrid=document.getElementById('favoriteGrid');
const search=document.getElementById('searchInput'), resultCount=document.getElementById('resultCount');
const empty=document.getElementById('emptyState'), favEmpty=document.getElementById('favoriteEmpty');
let category='all', query='', favorites=JSON.parse(localStorage.getItem('neonFavorites')||'[]');
function card(game){const saved=favorites.includes(game.id);return `<article class="game-card"><div class="game-cover ${game.cover}">${game.emoji}</div><div class="game-info"><div class="game-top"><h3>${game.name}</h3><button class="heart ${saved?'saved':''}" data-fav="${game.id}" aria-label="Toggle favorite">${saved?'♥':'♡'}</button></div><p>${game.desc}</p><div class="game-bottom"><span class="tag">${game.category}</span><button class="play-btn" data-play="${game.id}">PLAY ↗</button></div></div></article>`}
function render(){const shown=games.filter(g=>(category==='all'||g.category===category)&&(g.name+' '+g.desc+' '+g.category).toLowerCase().includes(query));grid.innerHTML=shown.map(card).join('');resultCount.textContent=`${shown.length} GAME${shown.length===1?'':'S'}`;empty.hidden=shown.length>0;const favs=games.filter(g=>favorites.includes(g.id));favGrid.innerHTML=favs.map(card).join('');favEmpty.hidden=favs.length>0; }
function toast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove('show'),2100)}
document.addEventListener('click',e=>{const play=e.target.closest('[data-play]');if(play){const game=games.find(g=>g.id===play.dataset.play);if(game)window.open(game.url,'_blank','noopener');return;}const fav=e.target.closest('[data-fav]');if(fav){const id=fav.dataset.fav;favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];localStorage.setItem('neonFavorites',JSON.stringify(favorites));render();toast(favorites.includes(id)?'Added to favorites':'Removed from favorites');}});
document.querySelectorAll('.filter').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.filter').forEach(b=>b.classList.remove('active'));btn.classList.add('active');category=btn.dataset.category;render()}));
search.addEventListener('input',()=>{query=search.value.toLowerCase();render()});
function showView(name){document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));document.getElementById(name+'View').classList.add('active');document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===name));document.getElementById('crumbName').textContent=name.toUpperCase();document.getElementById('sidebar').classList.remove('open');}
document.querySelectorAll('.nav-item').forEach(btn=>btn.addEventListener('click',()=>showView(btn.dataset.view)));
document.getElementById('exploreBtn').addEventListener('click',()=>document.getElementById('gameGrid').scrollIntoView({behavior:'smooth'}));
document.getElementById('mobileMenu').addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));
document.getElementById('sendChat').addEventListener('click',()=>{const input=document.getElementById('chatInput');const value=input.value.trim();if(!value)return;const row=document.createElement('p');row.textContent='You: '+value;row.style.cssText='font-size:12px;color:#c0c5dd;padding:8px 0;border-top:1px solid var(--line)';document.getElementById('chatMessages').appendChild(row);input.value='';});
document.getElementById('chatInput').addEventListener('keydown',e=>{if(e.key==='Enter')document.getElementById('sendChat').click()});
document.getElementById('motionToggle').addEventListener('change',e=>{document.body.classList.toggle('reduced-motion',e.target.checked)});
document.getElementById('clearFavorites').addEventListener('click',()=>{favorites=[];localStorage.removeItem('neonFavorites');render();toast('Favorites cleared')});
document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();search.focus()}});
render();